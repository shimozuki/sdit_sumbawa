<!-- resources/views/partials/footer.blade.php -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; SMP Islam Terpadu Samawa Cendekia</span>
        </div>
    </div>
</footer>
